# Aula de ReactJS com Typescript
## Com o professor Luiz Claudio na UniFOA

### Para tudo funcionar corretamente

 - É preciso Instalar as seguintes extensões no vscode
    - [vscode-styled-components](https://marketplace.visualstudio.com/items?itemName=jpoissonnier.vscode-styled-components)
    - [ESLint](https://marketplace.visualstudio.com/items?itemName=dbaeumer.vscode-eslint)
    - [Prettier - Code formatter](https://marketplace.visualstudio.com/items?itemName=esbenp.prettier-vscode) - (se achar interessante somente)

### Então ai podemos rodar o comando:
```
yarn start
```
